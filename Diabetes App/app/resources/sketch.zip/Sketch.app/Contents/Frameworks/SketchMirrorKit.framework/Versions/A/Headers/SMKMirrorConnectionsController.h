//
//  SMKPeerDiscoveryController.h
//  SketchMirrorKit
//
//  Created by Robin Speijer on 07-12-15.
//  Copyright © 2015 Awkward. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SMKMirrorDataSource.h"
#import "SMKMirrorConnectionsControllerDelegate.h"
#import "SMKPeerConnectionInfo.h"

extern NSString * _Nonnull SMKMirrorControllerDidChangeConnectionsNotification;

@class SMKPeer;

/// Manages the Mirror connections that can be used for mirror sessions. These connections are listed in the connections property. The delegate will be notified about any changes where the UI should be involved with. To send data to the Mirror clients, you can use the invalidation methods on this class.
@interface SMKMirrorConnectionsController : NSObject

/// The delegate to be called whenever there are changes to the connected Mirror clients or the Mirror Web URL changes.
@property (nullable, weak) id<SMKMirrorConnectionsControllerDelegate> delegate;

@property (readonly) BOOL usbEnabled;
@property (readonly) BOOL webEnabled;
@property (readonly) BOOL nearbyEnabled;

#pragma mark - Peers
/// @name Peers

/// The list of mirror connection infos to be displayed to the user.
@property (nullable, strong, readonly) NSOrderedSet<SMKPeerConnectionInfo *> *connections;

/// Whether this controller has any peers connected.
@property (readonly) BOOL hasConnectedPeers;

/// Manually connect to the specified peer
- (void)connectPeer:(nonnull SMKPeer *)peer;

/// Manually disconnect the specified peer
- (void)disconnectPeer:(nonnull SMKPeer *)peer;

/// Continues the given user activity. You typically call this from the -[UIApplicationDelegate application:continueUserActivity:restorationHandler:] method.
- (void)continueUserActivity:(nonnull NSUserActivity *)userActivity;

#pragma mark - Mirror Web

/// As network interfaces are subject to change and the built in webserver can not observe these system changes, it may be neccesary to update the web URL sometimes.
- (void)updateWebURL;

/// The Mirror Web URL to use. This note can be changed, which is notified to the delegate. As this URL does not contain any token, the connection should still be approved by the user.
@property (nullable, readonly) NSURL *webURL;


/**
 A Mirror Web URL that is already authorized. The user doesn't need to approve this new connection.
 
 @warning This method will create this URL synchronously on the Sketch Mirror process. The use of this property is discouraged. Use createAuthorizedWebURLWithHandler: instead. The only purpose of this method is that 3rd party developers can make use of it through the cocoascript APIs.
 */
@property (nullable, readonly) NSURL *authorizedWebURL DEPRECATED_MSG_ATTRIBUTE("Use createAuthorizedWebURLWithHandler: instead.");

/** 
 Creates a Mirror Web URL that contains an authorization token. This means that the opened browser is instantly connected to Sketch.
 @param handler A completion handler. The url parameter can be launched in the browser to open the authorized Mirror Web connection.
 */
- (void)createAuthorizedWebURLWithHandler:(void (^ _Nullable)(NSURL * _Nullable url))handler;


#pragma mark - Content updates
/// @name Content updates

/// The data source for all communication with Mirror apps
@property (nullable, weak) id<SMKMirrorDataSource> dataSource;

/// Invalidates the content hierarchy for all connections. The delegate will ask for new content whenever appropiate.
- (void)invalidateContent;

/// Invalidates the current artboard for all connections. The delegate will ask for the new current artboard whenever appropiate.
- (void)invalidateCurrentArtboard;

/**
 Invalidates the artboard image within the specified rectangle.
 
 This will mark this specific area within the image as dirty and places an update operation in the queue.
 @param identifier The artboard identifier to invalidate an image rectangle.
 @param rect The rectangle within the artboard image to invalidate. To invalidate the full image, specify CGRectZero.
 @param context A context object to use for the image invalidation. When the datasource is being asked about the image that needs to be rendered, the context can be included. However, the system might decide to not retain the context due to memory pressure.
 */
- (void)invalidateImageForArtboardIdentifier:(nonnull NSString *)identifier
                                      inRect:(CGRect)rect
                                     context:(nullable id)context;

@end
